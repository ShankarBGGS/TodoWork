import Todo from './components/Todo'

import './App.css'

const App = () => <Todo />

export default App

